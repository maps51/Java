package com.student.model;

public class StudentMS {
	int id;
	String name;
	String course;
	int totalMarks;
	
	public StudentMS(int id, String name, String course, int totalMarks) {
		super();
		this.id = id;
		this.name = name;
		this.course = course;
		this.totalMarks = totalMarks;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getCourse() {
		return course;
	}

	public void setCourse(String course) {
		this.course = course;
	}

	public int getTotalMarks() {
		return totalMarks;
	}

	public void setTotalMarks(int totalMarks) {
		this.totalMarks = totalMarks;
	}

	@Override
	public String toString() {
		return "StudentMS [id=" + id + ", name=" + name + ", course=" + course + ", totalMarks=" + totalMarks + "]";
	}
	
}
