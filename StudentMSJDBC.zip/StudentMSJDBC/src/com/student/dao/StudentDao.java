package com.student.dao;

import java.sql.SQLException;
import java.util.List;

import com.student.model.StudentMS;

public interface StudentDao {
	
	public void createStudentTable() throws SQLException;
	public void addStudent(StudentMS student) throws SQLException;
	public List<StudentMS> showAllStudents() throws SQLException;
	public void connect() throws SQLException;
	public void updateStudent(StudentMS student) throws SQLException;
	public void deleteStudent(int id) throws SQLException;
	public void findStudentById(int id) throws SQLException;
	public void findTopMarksandTopStudents() throws SQLException;
	
}
