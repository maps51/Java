package com.student.dao;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.student.model.StudentMS;

public class StudentDaoImpl implements StudentDao{
	
	Connection con;

	@Override
	public void createStudentTable() throws SQLException {
		Statement st=con.createStatement();
		String sql="create table Student(ID int, Name varchar(100), Course varchar(100), Total_Marks int) ";
		st.executeUpdate(sql);
		System.out.println("Student table is created");
		st.close();
		con.close();
	}

	@Override
	public void addStudent(StudentMS student) throws SQLException {
		PreparedStatement pst=con.prepareStatement("insert into Student values(?, ?, ?, ?)");
		pst.setInt(1, student.getId());
		pst.setString(2, student.getName());
		pst.setString(3, student.getCourse());
		pst.setInt(4, student.getTotalMarks());
		int count=pst.executeUpdate();
		System.out.println(count+ "record added in Student table.");
		pst.close();
		con.close();
	}

	@Override
	public List<StudentMS> showAllStudents() throws SQLException {
		Statement st=con.createStatement();
		List<StudentMS> students=new ArrayList<>();
		ResultSet rs=st.executeQuery("select * from Student");
		while(rs.next()) {
			students.add(new StudentMS(rs.getInt(1), rs.getString(2), rs.getString(3), rs.getInt(4)));
		}
		st.close();
		rs.close();
		con.close();
		return students;
		
	}

	@Override
	public void connect() throws SQLException {
		
		String url="jdbc:mysql://localhost:3306/StudentManagementSystem";
		String user="root";
		String pwd="akka2023";
		con=DriverManager.getConnection(url, user, pwd);
		
	}

	@Override
	public void updateStudent(StudentMS student) throws SQLException {
		
		PreparedStatement pst=con.prepareStatement("update Student set Name=?, Course=?, Total_Marks=? where ID=?");
		pst.setString(1,student.getName());
		pst.setString(2, student.getCourse());
		pst.setInt(3, student.getTotalMarks());
		pst.setInt(4, student.getId());
		int count=pst.executeUpdate();
		System.out.println(count+" records affected successfully");
		pst.close();
		con.close();
		
	}

	@Override
	public void deleteStudent(int id) throws SQLException {
		
		PreparedStatement pst=con.prepareStatement("delete from Student where ID=?");
		pst.setInt(1, id);
		int count=pst.executeUpdate();
		System.out.println(count+ "record deleted successfully");
		pst.close();
		con.close();
		
	}

	@Override
	public void findStudentById(int id) throws SQLException {
		
		String sql2="select * from Student where ID=?";
		PreparedStatement pst=con.prepareStatement(sql2);
		pst.setInt(1, id);
		ResultSet rs=pst.executeQuery();
		while(rs.next()) {
			System.out.println(rs.getInt(1)+" "+rs.getString(2)+" "+rs.getString(3)+" "+rs.getInt(4));
		}
		
		pst.close();
		rs.close();
		con.close();
		
		
	}

	@Override
	public void findTopMarksandTopStudents() throws SQLException {
		
		String sql3=("{call findTopMarksTopStudents()}");
		CallableStatement call=con.prepareCall(sql3);
		ResultSet rs=call.executeQuery();
		while(rs.next()) {
			System.out.println(rs.getInt(1)+" "+rs.getString(2)+" "+rs.getString(3)+" "+rs.getInt(4));
		}
		call.close();
		rs.close();
		con.close();
	}
	
	
	
	
}
//findStudentById(id)-->stored function findTopMarks--->findTopStudent