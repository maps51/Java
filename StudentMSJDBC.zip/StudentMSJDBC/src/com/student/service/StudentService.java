package com.student.service;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import com.student.dao.StudentDaoImpl;
import com.student.model.StudentMS;

public class StudentService {

	public static void main(String[] args) throws SQLException {
		
		StudentDaoImpl dao=new StudentDaoImpl();
		int choice;
		Scanner sc=new Scanner(System.in);
		int id, totalMarks;
		String name, course;
		StudentMS student;
		
		do {
			System.out.println("Menu: \n1. Create Table Student \n2. Add new Student \n3. Show all Students \n4. Update Student \n5. Delete Student \n6. Find Student \n7. Find Top Marks and Top Student \nEnter your choice:");
			choice=sc.nextInt();
			switch(choice) {
			case 1:
				dao.connect();
				dao.createStudentTable();
				break;
				
			case 2:
				dao.connect();
				System.out.println("Enter the details of the Student: ID, Name, Course, Total Marks ");
				id=sc.nextInt();
				name=sc.next();
				course=sc.next();
				totalMarks=sc.nextInt();
				student=new StudentMS(id, name, course, totalMarks);
				dao.addStudent(student);
				break;
				
			case 3:
				dao.connect();
				List<StudentMS> students=new ArrayList<>();
				students=dao.showAllStudents();
				for (StudentMS s:students)
					System.out.println(s);
				break;
				
			case 4:
				dao.connect();
				System.out.println("Enter the id of student which you want to change: ");
				id=sc.nextInt();
				System.out.println("Enter the new name for update: ");
				name=sc.next();
				System.out.println("Enter the new course: ");
				course=sc.next();
				System.out.println("Enter the new total marks: ");
				totalMarks=sc.nextInt();
				student=new StudentMS(id, name, course, totalMarks);
				dao.updateStudent(student);
				break;
				
			case 5:
				dao.connect();
				System.out.println("Enter the id of the student to delete: ");
				id=sc.nextInt();
				dao.deleteStudent(id);
				break;
				
			case 6:
				dao.connect();
				System.out.println("Enter the id of the student: ");
				id=sc.nextInt();
				dao.findStudentById(id);
				break;
				
			case 7:
				dao.connect();
				dao.findTopMarksandTopStudents();
				break;
				
			}
		}while(choice!=0);
		
		sc.close();
	}

}

//DAO Pattern
//Model-->Project
//DAO interface-->abstract interface-->implement all methods
//DAO implement all methods
//DAO service layer-->create object of DAO class

//ProductMS
//Packages:
//com.product.dao-->ProductDao.java(interface), ProductDaoImpl.java(class)
//com.product.model-->Product.java
//com.product.service-->ProductService.java, Sample.java
