/**
 * 
 */
/**
 * 
 */
module StudentMSJDBC {
	requires java.sql;
}